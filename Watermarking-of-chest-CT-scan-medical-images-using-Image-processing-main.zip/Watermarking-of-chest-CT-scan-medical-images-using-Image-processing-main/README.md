# Watermarking-of-chest-CT-scan-medical-images-using-Image-processing
Watermarking of chest CT scan medical images for content authentication
